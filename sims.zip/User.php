<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Auth\Passwords\CanResetPassword;
use Kyslik\ColumnSortable\Sortable;
use Claass;
class User extends Authenticatable
{
    use Notifiable;
    use Sortable;
    protected $primaryKey = 'gr_no';
    //protected $foreignKey = 'class_id';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'gr_no','f_name','m_name','l_name','email','password','phone_no','dob','address','landmark','city','zipcode','gender','mother_name','father_name','parent_email','parent_phone_no','class_id','batch_id','commitee_id','post_id','sem_id'
    ];

    public $sortable = ['gr_no','f_name','m_name','l_name','email','password','phone_no','dob','address','landmark','city','zipcode','gender','mother_name','father_name','parent_email','parent_phone_no','class_id','batch_id','commitee_id','post_id','sem_id'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
    
    public function claass(){
        return $this->belongsTo('App\Claass','class_id');
    }

    public function batch(){
        return $this->belongsTo('App\Batch','batch_id');
    }

    public function attendances(){
        return $this->hasMany('App\Attendance');
    }

    public function results(){
        return $this->hasMany('App\Result');
    }
}
