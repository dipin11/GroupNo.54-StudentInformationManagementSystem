<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Subject;
use App\Staff;
use Auth;
class SubjectsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
        //$this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $subjects= Subject::sortable()->orderBy('sem_id','asc')->get();
        return view('/admin/subject/index')->with('subjects',$subjects);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/subject')->with('error','Unauthorize Access');
        }
        $staffss=array();
        $staffs=Staff::orderBy('staff_id')->get();
        foreach($staffs as $staff){
            $staffss[]=array($staff->staff_id => $staff->staff_name);
        }
        return  view('/admin/subject/create')->with('staffs',$staffss);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/subject')->with('error','Unauthorize Access');
        }
        $this->validate($request, [
            'subject_id' => 'required|string|unique:subject',
            'subject_name' => 'required|string|max:255',
            'subject_code' => 'required|string|max:10',
            'sem_id' => 'required|numeric',
            'branch' => 'required|string',
            'theory_hours' => 'required|numeric',
            'practical_hours' => 'required|numeric',
            'tutorial_hours' => 'required|numeric',
            'theory_credit' => 'required|numeric',
            'practical_credit' => 'required|numeric',
            'tutorial_credit' => 'required|numeric',
            'internal_ass_1' => 'required|numeric',
            'internal_ass_2' => 'required|numeric',
            'internal_ass_avg' => 'required|numeric',
            'term_work' => 'required|numeric',
            'practical_oral_marks' => 'required|numeric',
            'end_sem_marks' => 'required|numeric',
            'total_marks' => 'required|numeric',
            'exam_duration' => 'required|numeric',
        ]);
        $sem_id=$request->sem_id++;
        $year='';
        if($sem_id==1 || $sem_id==2){
            $year='FE';
        }
        elseif($sem_id==3 || $sem_id==4){
            $year='SE';
        }
        elseif($sem_id==5 || $sem_id==6){
            $year='TE';
        }
        elseif($sem_id==7 || $sem_id==8){
            $year='BE';
        }
        $branch='';
        if($request->branch==0){
            $branch='IT';
        }
        elseif($request->branch==1){
            $branch='CS';
        }
        $subject_incharge=$request->subject_incharge;
        $subject=new Subject;
        $subject->subject_id=$request->subject_id;
        $subject->subject_name=$request->subject_name;
        $subject->subject_code=$request->subject_code;
        $subject->sem_id=$sem_id;
        $subject->year=$year;
        $subject->branch=$branch;
        $subject->theory_hours=$request->theory_hours;
        $subject->practical_hours=$request->practical_hours;
        $subject->tutorial_hours=$request->tutorial_hours;
        $subject->theory_credit=$request->theory_credit;
        $subject->practical_credit=$request->practical_credit;
        $subject->tutorial_credit=$request->tutorial_credit;
        $subject->internal_ass_1=$request->internal_ass_1;
        $subject->internal_ass_2=$request->internal_ass_2;
        $subject->internal_ass_avg=$request->internal_ass_avg;
        $subject->term_work=$request->term_work;
        $subject->practical_oral_marks=$request->practical_oral_marks;
        $subject->exam_duration=$request->exam_duration;
        $subject->end_sem_marks=$request->end_sem_marks;
        $subject->total_marks=$request->total_marks;
        $subject->subject_incharge=$subject_incharge;

        $subject->save();

        return redirect('/auth/subject')->with('success','Subject Created.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $subject=Subject::find($id);
        $incharge=Staff::find($subject->subject_incharge);
        $subject=Subject::find($id);
        return view('admin/subject/show')->with('subject',$subject)->with('incharge',$incharge);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/subject')->with('error','Unauthorize Access');
        }
        $staffss=array();
        $staffs=Staff::orderBy('staff_id')->get();
        foreach($staffs as $staff){
            $staffss[]=array($staff->staff_id => $staff->staff_name);
        }
        $subject=Subject::find($id);
        return view('admin/subject/edit')
        ->with('subject',$subject)
        ->with('staffs',$staffss);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/subject')->with('error','Unauthorize Access');
        }
        $this->validate($request, [
            'subject_name' => 'required|string|max:255',
            'subject_code' => 'required|string|max:10',
            'sem_id' => 'required|numeric',
            'branch' => 'required|string',
            'theory_hours' => 'required|numeric',
            'practical_hours' => 'required|numeric',
            'tutorial_hours' => 'required|numeric',
            'theory_credit' => 'required|numeric',
            'practical_credit' => 'required|numeric',
            'tutorial_credit' => 'required|numeric',
            'internal_ass_1' => 'required|numeric',
            'internal_ass_2' => 'required|numeric',
            'internal_ass_avg' => 'required|numeric',
            'term_work' => 'required|numeric',
            'practical_oral_marks' => 'required|numeric',
            'end_sem_marks' => 'required|numeric',
            'total_marks' => 'required|numeric',
            'exam_duration' => 'required|numeric',
        ]);
        $subject_incharge=$request->subject_incharge;
        $sem_id=$request->sem_id++;
        $year='';
        if($sem_id==1 || $sem_id==2){
            $year='FE';
        }
        elseif($sem_id==3 || $sem_id==4){
            $year='SE';
        }
        elseif($sem_id==5 || $sem_id==6){
            $year='TE';
        }
        elseif($sem_id==7 || $sem_id==8){
            $year='BE';
        }
        $branch='';
        if($request->branch==0){
            $branch='IT';
        }
        elseif($request->branch==1){
            $branch='CS';
        }
        $subject=Subject::find($id);
        $subject->subject_id=$request->subject_id;
        $subject->subject_name=$request->subject_name;
        $subject->subject_code=$request->subject_code;
        $subject->sem_id=$sem_id;
        $subject->year=$year;
        $subject->branch=$branch;
        $subject->theory_hours=$request->theory_hours;
        $subject->practical_hours=$request->practical_hours;
        $subject->tutorial_hours=$request->tutorial_hours;
        $subject->theory_credit=$request->theory_credit;
        $subject->practical_credit=$request->practical_credit;
        $subject->tutorial_credit=$request->tutorial_credit;
        $subject->internal_ass_1=$request->internal_ass_1;
        $subject->internal_ass_2=$request->internal_ass_2;
        $subject->internal_ass_avg=$request->internal_ass_avg;
        $subject->term_work=$request->term_work;
        $subject->practical_oral_marks=$request->practical_oral_marks;
        $subject->exam_duration=$request->exam_duration;
        $subject->end_sem_marks=$request->end_sem_marks;
        $subject->total_marks=$request->total_marks;
        $subject->subject_incharge=$subject_incharge;
        
        $subject->save();

        return redirect('/auth/subject')->with('success','Subject Updated.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/subject')->with('error','Unauthorize Access');
        }
        $subject=Subject::find($id);
        $subject->delete();
        return redirect('/auth/subject')->with('success','Subject Removed Successfully.');
    }
}
