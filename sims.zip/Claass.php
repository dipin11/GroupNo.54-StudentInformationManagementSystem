<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
class Claass extends Model
{
    protected $guard ='admin';
    protected $table='class';
    protected $primaryKey ='class_id';

    public function users(){
        return $this->hasMany('App\User');
    }

    public function batchs(){
        return $this->hasMany('App\Batch');
    }
}
