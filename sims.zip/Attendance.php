<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class Attendance extends Model
{
    use Sortable;
    protected $guard ='admin';
    protected $table='attendance';
    protected $primaryKey ='attendance_id';

    public $sortable = ['attendance_id', 'gr_no', 'subject_id'];

    public function user(){
        return $this->belongsTo('App\User','class_id');
    }
}
