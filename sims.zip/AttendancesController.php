<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Claass;
use App\Subject;
use App\Attendance;
use Auth;
use Illuminate\Support\Facades\Input;
class AttendancesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin')->except('attended');
        //$this->middleware('auth');
    }
    public function index()
    {
        $students= User::sortable()->orderBy('sem_id','asc')->get();
        $attendance=array();
        foreach($students as $student){
            $gr=$student->gr_no;
            $totalCount=Attendance::where('gr_no','=',$gr)->count();
            $presentCount=Attendance::where('gr_no','=',$gr)->where('attended_remark','P')->count();
            if($totalCount==0){
                $attendance[]=0;
                continue;
            }
            $attendance[]=($presentCount/$totalCount)*100;
        }
        return view('/admin/attendance/index')->with('students',$students)->with('attendance',$attendance);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $grs=array();
        $allgrs=array();
        $mark='Temp';
        $markInv='Temp';
        $allgrs=$request->allgrs;
        $class=$request->class;
        $subject_code=$request->subject_code;
        $subject_id=$request->subject_ids[$subject_code];
        if($request->has('options')){
            $grs=$request->options;
        }
        if($request->mark==0){
            $mark='A';
            $markInv='P';
        }
        else{
            $mark='P';
            $markInv='A';
        }
        //for all gr
        foreach($allgrs as $allgr){
            $attendance=new Attendance;
            $attendance1=new Attendance;
            $flag=0;
            //check for marked grs and make their entry
            foreach($grs as $gr){
                if($gr==$allgr){
                    if($request->practicals){
                        $attendance->attended_remark=$mark;
                        $attendance->gr_no=$gr;
                        $attendance->subject_id=$subject_id;
                        $attendance->type="practical";
                        $attendance->staff_id=Auth::guard('admin')->user()->staff_id;
                        $attendance->save();
                        $attendance1->attended_remark=$mark;
                        $attendance1->gr_no=$gr;
                        $attendance1->subject_id=$subject_id;
                        $attendance1->type="practical";
                        $attendance1->staff_id=Auth::guard('admin')->user()->staff_id;
                        $attendance1->save();
                    }
                    else{
                        $attendance->attended_remark=$mark;
                        $attendance->gr_no=$gr;
                        $attendance->subject_id=$subject_id;
                        $attendance->type="lecture";
                        $attendance->staff_id=Auth::guard('admin')->user()->staff_id;
                        $attendance->save();
                    }
                    $flag=1;
                    break;
                }
            }
            if($flag==0){
                if($request->practicals){
                    $attendance->attended_remark=$markInv;
                    $attendance->gr_no=$allgr;
                    $attendance->subject_id=$subject_id;
                    $attendance->type="practical";
                    $attendance->staff_id=Auth::guard('admin')->user()->staff_id;
                    $attendance->save();
                    $attendance1->attended_remark=$markInv;
                    $attendance1->gr_no=$allgr;
                    $attendance1->subject_id=$subject_id;
                    $attendance1->type="practical";
                    $attendance1->staff_id=Auth::guard('admin')->user()->staff_id;
                    $attendance1->save();
                }else{
                    $attendance->attended_remark=$markInv;
                    $attendance->gr_no=$allgr;
                    $attendance->subject_id=$subject_id;
                    $attendance->type="lecture";
                    $attendance->staff_id=Auth::guard('admin')->user()->staff_id;
                    $attendance->save();
                }
            }            
        }
        return redirect('/auth/attendance')->with('success','Attendance of '.$class.' marked successfully.');
        //return view('admin/attendance/temp')->with('array',$array);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function attended(Request $request){
        $student_gr=$request->gr;
        $subject_id=$request->subject;
        $student=User::find($student_gr);
        $student_name=$student->l_name.' '.$student->f_name.' '.$student->m_name.' '.$student->mother_name;
        $attendances=Attendance::where('subject_id','=',$subject_id)->where('gr_no','=',$student_gr)->get();
        $subject=Subject::find($subject_id);
        $subject_name=$subject->subject_name;
        $subject_code=$subject->subject_code;
        
        return view('admin/attendance/attended')
        ->with('subject_name',$subject_name)
        ->with('subject_code',$subject_code)
        ->with('attendances',$attendances)
        ->with('student_gr',$student_gr)
        ->with('student_name',$student_name);

    }

    public function init_lecture(Request $request){
        $year='Temp';
        $course='Temp';
        $sem=$request->sem_id;
        $section=$request->section;
        $year='BE';
        if($request->course==0){
            $course='D17';
        }
        elseif($request->course==1){
            $course='D19';
        }
        if($sem==0){
            $sem=7;
        }
        elseif($sem==1){
            $sem=8;
        }
        $section=$request->section+1;
        $class=Claass::where('year','=',$year)->where('course','=',$course)->where('class_section','=',$section)->get();
        $students=User::where('class_id','=',$class[0]->class_id)->where('sem_id','=',$sem)->get();
        $subjects=array();
        if((Auth::guard('admin')->user()->roles)===0){
            $subjects=Subject::where('sem_id','=',$sem)->get();
        }
        else{
            $subjects=Subject::where('sem_id','=',$sem)->where('subject_incharge','=',Auth::guard('admin')->user()->staff_id)->get();
        }
        $subject_names=array();
        $subject_codes=array();
        $subject_ids=array();
        foreach($subjects as $subject){
            $subject_names[]=$subject->subject_name;
            $subject_codes[]=strtoupper($subject->subject_code);
            $subject_ids[]=$subject->subject_id;
        }
        $practicals=false;
        $select_class=$class[0]->year.'-'.$class[0]->course.'-'.$class[0]->class_section;
        return view('admin/attendance/create')
        ->with('subject_names',$subject_names)
        ->with('subject_codes',$subject_codes)
        ->with('subject_ids',$subject_ids)
        ->with('class',$select_class)
        ->with('students',$students)
        ->with('practicals',$practicals);
    }

    public function init_practical(Request $request){
        $year='Temp';
        $course='Temp';
        $sem=$request->sem_id;
        $section=$request->section;
        $year='BE';
        if($request->course==0){
            $course='D17';
        }
        elseif($request->course==1){
            $course='D19';
        }
        if($sem==0){
            $sem=7;
        }
        elseif($sem==1){
            $sem=8;
        }
        $section=$request->section+1;
        $class=Claass::where('year','=',$year)->where('course','=',$course)->where('class_section','=',$section)->get();
        $students=User::where('class_id','=',$class[0]->class_id)->where('sem_id','=',$sem)->get();
        $subjects=Subject::where('sem_id','=',$sem)->get();
        $subject_names=array();
        $subject_codes=array();
        $subject_ids=array();
        foreach($subjects as $subject){
            $subject_names[]=$subject->subject_name;
            $subject_codes[]=strtoupper($subject->subject_code);
            $subject_ids[]=$subject->subject_id;
        }
        $practicals=true;
        $select_class=$class[0]->year.'-'.$class[0]->course.'-'.$class[0]->class_section;
        return view('admin/attendance/create')
        ->with('subject_names',$subject_names)
        ->with('subject_codes',$subject_codes)
        ->with('subject_ids',$subject_ids)
        ->with('class',$select_class)
        ->with('students',$students)
        ->with('practicals',$practicals);
    }
    
}
