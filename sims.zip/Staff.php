<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Staff extends Model
{
    protected $guard ='admin';
    protected $table='staff';
    protected $primaryKey ='staff_id';
    public $incrementing = false;
    public $timestamps=false;
}