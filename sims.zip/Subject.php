<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;
class Subject extends Model
{
    use Sortable;
    public $sortable = ['subject_name','subject_id','subject_code','sem_id'];
    protected $guard ='admin';
    protected $table='subject';
    protected $primaryKey ='subject_id';
    public $timestamps=false;
    public $incrementing = false;
}
