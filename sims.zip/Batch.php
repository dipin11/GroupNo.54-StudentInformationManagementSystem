<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Batch extends Model
{
    protected $guard ='admin';
    protected $table='batch';
    protected $primaryKey ='batch_id';

    public function users(){
        return $this->hasMany('App\User');
    }

    public function claass(){
        return $this->belongsTo('App\Claass','class_id');
    }
}
