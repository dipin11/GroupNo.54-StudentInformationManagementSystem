<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\DB;
use App\Claass;
use App\Subject;
use App\Attendance;
use App\Result;
use Auth;
class UsersController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin',['except'=>'show']);
        //$this->middleware('auth');
    }
    
    public function index()
    {
        $students= User::sortable()->orderBy('created_at','desc')->paginate(20);
        return view('/admin/student/index')->with('students',$students);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function create()
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/student')->with('error','Unauthorize Access');
        }
        return  view('/admin/student/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/student')->with('error','Unauthorize Access');
        }
        $this->validate($request, [
            'gr_no' => 'required|numeric|unique:users',
            'f_name' => 'required|string|max:255',
            'm_name' => 'required|string|max:255',
            'l_name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
            'phone_no' => 'required|string|max:10',
            'dob' => 'required|date',
            'address' => 'required|string|max:255',
            'landmark' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'zipcode' => 'required|string|max:6',
            'gender' => 'required|string',
            'mother_name' => 'required|string|max:255',
            'father_name' => 'required|string|max:255',
            'parent_email' => 'required|string|email|max:255',
            'parent_phone_no' => 'required|string|max:10',
        ]);
        if($request->gender==0){
            $gender='Male';
        }elseif($request->gender==1){
            $gender='Female';
        }else{
            $gender='Other';
        }
        $array=array(
            'gr_no'=>$request->gr_no,
            'f_name'=>$request->f_name,
            'm_name'=>$request->m_name,
            'l_name'=>$request->l_name,
            'email'=>$request->email,
            'password'=>bcrypt($request->password),
            'phone_no'=>$request->phone_no,
            'dob' => $request->dob,
            'address' => $request->address,
            'landmark' => $request->landmark,
            'city' => $request->city,
            'zipcode' => $request->zipcode,
            'gender' => $gender,
            'mother_name' => $request->mother_name,
            'father_name' => $request->father_name,
            'parent_email' => $request->parent_email,
            'parent_phone_no' => $request->parent_phone_no,
        );
        $user=User::create($array);
        return redirect('/admin/dashboard')->with('success','Student Created.');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $student=User::find($id);
        $sem=$student->sem_id;
        $attendances=array();
        $subjects=Subject::where('sem_id',$sem)->get();
        $results=Result::where('gr_no','=',$student->gr_no)->orderby('sem_id')->get();
        $semesters=Result::orderBy('sem_id')->distinct()->get(['sem_id']);
        foreach($subjects as $subject){
            $total=Attendance::where('gr_no','=',$student->gr_no)->where('subject_id','=',$subject->subject_id)->count();
            $totalPresent=Attendance::where('gr_no','=',$student->gr_no)->where('subject_id','=',$subject->subject_id)->where('attended_remark','=','P')->count();
            if($total==0){
                $attendances[]=0;
            }else{
                $attendances[]=($totalPresent/$total)*100;
            }
            
        }
        if(Auth::guard('admin')->guest()){
            $id1=(int)auth()->user()->gr_no;
            $id=(int)$id;
            if($id1!==$id){
                return redirect('/student/dashboard')->with('error','Unauthorized Access');
            }
        }
        $class=$student->claass->year.'-'.$student->claass->course.'-'.$student->claass->class_section;
        return view('admin/student/show')
        ->with('student',$student)
        ->with('class',$class)
        ->with('attendances',$attendances)
        ->with('results',$results)
        ->with('semesters',$semesters)
        ->with('subjects',$subjects);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function classWise(Request $request){
        // $students= User::where('batch_id','=',$request->section)->paginate(40);
        // return view('/admin/student/filtered')->with('students',$students);
        if($request->year==0 && $request->course==0){
            $students= User::sortable()->orderBy('created_at','desc')->paginate(40);
            return redirect('/auth/student')->with('students',$students);
        }
        $year='TEMP';
        if($request->year==1){
            $year='FE';
        }
        elseif($request->year==2){
            $year='SE';
        }
        elseif($request->year==3){
            $year='TE';
        }
        elseif($request->year==4){
            $year='BE';
        }
        $course='TEMP';
        if($request->course==1){
            $course='D17';
        }
        elseif($request->course==2){
            $course='D19';
        }
        $classes;
        if($year=='TEMP' && $course!=='TEMP'){
            $classes= Claass::Where('course','=',$course)->get();
        }
        elseif($year!=='TEMP' && $course=='TEMP'){
            $classes= Claass::where('year','=',$year)->get();
        }
        elseif($year!=='TEMP' && $course!=='TEMP'){
            $classes= Claass::where('year','=',$year)->Where('course','=',$course)->get();
        }
        $students= User::sortable()->orderBy('gr_no','asc')->get();
        return view('/admin/student/filtered')->with('year',$year)->with('course',$course)->with('students',$students);

    }
}