<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Auth;

class AdminLoginController extends Controller
{
    public function __construct(){
        $this->middleware('guest:admin');
    }
    public function showLoginForm(){
        return view('auth/admin-login');
    }
    public function login(Request $request){
        
        $this->validate($request,[
            'email'=>'required|email',
            'password'=>'required|min:6'
        ]);
        
        $userdata = array(
            'email'     => $request->email,
            'password'  => $request->password
        );
    
        // attempt to do the login
        if (Auth::guard('admin')->attempt($userdata,$request->remember)) {

            return redirect()->intended(route('admin.dashboard'))->with('success','You are logged-in as Admin.');
    
        } else {        
    
            // validation not successful, send back to form 
            return redirect()->back()->withInput($request->only('email','remember'))->with('error','Invalid Credentials.');
        }

    }


}
