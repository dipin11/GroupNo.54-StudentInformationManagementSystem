<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Staff;
use App\Admin;
use Auth;
class StaffsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
        //$this->middleware('auth');
    }
    public function index()
    {
        $staffs= Staff::orderBy('staff_id','asc')->paginate(6);
        return view('/admin/staff/index')->with('staffs',$staffs);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/staff')->with('error','Unauthorize Access');
        }
        return view('admin/staff/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/staff')->with('error','Unauthorize Access');
        }
        $this->validate($request , [
                'staff_id' => 'required|numeric|unique:staff',
                'staff_name' => 'required|string',
                'staff_code' => 'required|string|unique:staff',
                'staff_email_id' => 'required|string',
                'branch' => 'required|numeric',
                'phone_no' => 'required|numeric',
                'dob' => 'required|date',
                'city' => 'required|string',
                'address' => 'required|string',
                'qualification' => 'required|string',
                'specialization' => 'required|string',
                'password' => 'required|string',
            ]
        );

        $staff = new Staff;
        $staff->staff_id=$request->staff_id;
        $staff->staff_name = $request->staff_name;
        $staff->staff_code = $request->staff_code;
        $staff->staff_email_id = $request->staff_email_id;
        if($request->branch==0){
            $staff->branch = 'IT';
        }else{
            $staff->branch = 'CS';
        }
        if($request->post==0){
            $staff->post = 'Assistant Professor';
        }elseif($request->post==1){
            $staff->post = 'Associate Professor';
        }else{
            $staff->post = 'Professor';
        }
        $staff->phone_no = $request->phone_no;
        $staff->dob = $request->dob;
        $staff->address = $request->address;
        $staff->city = $request->city;
        $staff->qualification = $request->qualification;
        $staff->specialization = $request->specialization;
        $array=array(
            'email'=>$request->staff_email_id,
            'name'=>$request->staff_name,
            'staff_id'=>$request->staff_id,
            'password'=>bcrypt($request->password),
            'role'=>1,
        );
        Admin::create($array);
        $staff->save();

        
        return redirect('/auth/staff')->with('success','Staff Created.');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $staff=Staff::find($id);
        return view('admin/staff/show')->with('staff',$staff);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/staff')->with('error','Unauthorize Access');
        }
        $staff=Staff::find($id);
        return view('admin/staff/edit')->with('staff',$staff);    
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/staff')->with('error','Unauthorize Access');
        }
        $this->validate($request , [
            'staff_id' => 'required|numeric',
            'staff_name' => 'required|string',
            'staff_code' => 'required|string',
            'staff_email_id' => 'required|string',
            'branch' => 'required|string',
            'phone_no' => 'required|numeric',
            'dob' => 'required|date',
            'city' =>'required|string',
            'address' => 'required|string',
            'qualification' => 'required|string',
            'specialization' => 'required|string',
            ]
        );

        $staff=Staff::find($id);
        $staff->staff_name = $request->staff_name;
        $staff->staff_code = $request->staff_code;
        $staff->staff_email_id = $request->staff_email_id;
        if($request->branch==0){
            $staff->branch = 'IT';
        }else{
            $staff->branch = 'CS';
        }
        if($request->post==0){
            $staff->post = 'Assistant Professor';
        }elseif($request->post==1){
            $staff->post = 'Associate Professor';
        }else{
            $staff->post = 'Professor';
        }
        $staff->city = $request->city;
        $staff->phone_no = $request->phone_no;
        $staff->dob = $request->dob;
        $staff->address = $request->address;
        $staff->qualification = $request->qualification;
        $staff->specialization = $request->specialization;
        $staff->save();

        
        return redirect('/auth/staff')->with('success','Staff details updated.');

    }
    
    public function destroy($id)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/staff')->with('error','Unauthorize Access');
        }
        $staff=Staff::find($id);
        $admin=Admin::where('staff_id',$id);
        $admin->delete();
        $staff->delete();
        return redirect('/auth/staff')->with('success','Staff Removed Successfully.');
    }
}
