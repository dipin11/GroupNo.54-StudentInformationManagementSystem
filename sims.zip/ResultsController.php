<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Result;
use App\User;
use Auth;
class ResultsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $semesters=Result::orderBy('sem_id')->distinct()->get(['sem_id']);
        $results=Result::orderBy('gr_no')->orderBy('sem_id')->get();
        return view('/admin/result/index')
        ->with('results',$results)
        ->with('semesters',$semesters);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/result')->with('error','Unauthorize Access');
        }
        $sem=$request->sem_id;
        $year='BE';
        if($sem==0){
            $sem=5;
        }
        elseif($sem==1){
            $sem=6;
        }
        elseif($sem==2){
            $sem=7;
        }
        elseif($sem==3){
            $sem=8;
        }
        $results=Result::where('sem_id','=',$sem)->get();
        if(count($results)!==0){
            return redirect('/auth/result')->with('error','Result already declared for semester '.$sem);
        }
        $students=User::where('sem_id','=',$sem)->get();
        
        return view('/admin/result/create')
        ->with('students',$students)
        ->with('sem',$sem);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/result')->with('error','Unauthorize Access');
        }
        $results=$request->results;
        $allgrs=$request->allgrs;
        for($i=0;$i<count($allgrs);$i++){
            $remark='F';
            $result=new Result;
            $result->gr_no=$allgrs[$i];
            $result->pointer=$results[$i];
            if($results[$i]<=10 && $results[$i]>=9){
                $remark='O';
            }elseif($results[$i]<9 && $results[$i]>=8){
                $remark='A';
            }elseif($results[$i]<8 && $results[$i]>=7){
                $remark='B';
            }elseif($results[$i]<7 && $results[$i]>=6){
                $remark='C';
            }elseif($results[$i]<6 && $results[$i]>=5){
                $remark='D';
            }elseif($results[$i]<5 && $results[$i]>=4){
                $remark='E';
            }else{
                $remark='F';
            }
            $result->pointer=$results[$i];
            $result->remark=$remark;
            $result->gr_no=$allgrs[$i];
            $result->sem_id=$request->sem;
            $result->save();
        }
        return redirect('/auth/result')->with('success','Result uploaded successfully for Semester '.$request->sem);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/result')->with('error','Unauthorize Access');
        }
        $result=Result::find($id);
        return view('/admin/result/edit')
        ->with('result',$result);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/result')->with('error','Unauthorize Access');
        }
        $remark='F';
        $result=Result::find($id);
        $gr=$result->gr_no;
        $sem=$result->sem_id;
        $pointer=$request->pointer;
        if($pointer<=10 && $pointer>=9){
            $remark='O';
        }elseif($pointer<9 && $pointer>=8){
            $remark='A';
        }elseif($pointer<8 && $pointer>=7){
            $remark='B';
        }elseif($pointer<7 && $pointer>=6){
            $remark='C';
        }elseif($pointer<6 && $pointer>=5){
            $remark='D';
        }elseif($pointer<5 && $pointer>=4){
            $remark='E';
        }else{
            $remark='F';
        }
        $result->gr_no=$gr;
        $result->pointer=$pointer;
        $result->remark=$remark;
        $result->sem_id=$sem;
        $result->save();
        return redirect('/auth/result')->with('success','Result updated successfully for GR '.$gr.' for Semester '.$sem);
    }

    public function delete(Request $request)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/staff')->with('error','Unauthorize Access');
        }
        $sem=$request->sem_id;
        if($sem==0){
            $sem=5;
        }
        elseif($sem==1){
            $sem=6;
        }
        elseif($sem==2){
            $sem=7;
        }
        elseif($sem==3){
            $sem=8;
        }
        $results=Result::where('sem_id','=',$sem)->get();
        foreach($results as $result){
            self::destroy($result->result_id);
        }
        return  redirect('/auth/result')->with('success','Result deleted for semester '.$sem);
    }

    public function destroy($id)
    {
        if(Auth::guard('admin')->user()->roles===1){
            return  redirect('/auth/staff')->with('error','Unauthorize Access');
        }
        $result=Result::find($id);
        $result->delete();
    }
}
