<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    //
    function index(){
        return view('pages/index');
    }

    function placements(){
        return view('pages/placements');
    }

    function announcements(){
        return view('pages/announcements');
    }

    function departments(){
        return view('pages/departments');
    }

    function about(){
        return view('pages/about');
    }
}
