<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Result extends Model
{
    protected $guard ='admin';
    protected $table='result';
    protected $primaryKey ='result_id';
    public $timestamps=false;

    public function user(){
        return $this->belongsTo('App\User','gr_no');
    }
}
